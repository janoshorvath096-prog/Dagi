package hu.haromszam.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Foreground microphone-service shell.
 *
 * IMPORTANT: This service deliberately does NOT pretend to detect the wake phrase yet.
 * A real wake-word engine and its trained "Szia 23" model must be integrated.
 */
class WakeWordService : Service(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(23, buildNotification("A 23 hangfigyelő szolgáltatása aktív"))
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // TODO: Integrate a local wake-word engine (e.g. Porcupine or sherpa-onnx)
        // with a custom model trained for the Hungarian phrase "Szia 23".
        return START_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hu", "HU")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "23_mic", "23 hangfigyelés", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "A 23 mikrofonfigyelő szolgáltatásának értesítése" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, "23_mic") else Notification.Builder(this)
        return builder.setContentTitle("23 – hangfigyelés")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
