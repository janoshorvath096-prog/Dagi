package hu.haromszam.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val requestCode = 2301

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 40, 28, 40)
            setBackgroundColor(Color.rgb(8, 8, 8))
        }
        val title = TextView(this).apply {
            text = "23"
            textSize = 54f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(244, 216, 137))
        }
        val subtitle = TextView(this).apply {
            text = "ARTIFICIAL INTELLIGENCE\n\nA hangaktiválás előkészítő verziója"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(214, 173, 80))
        }
        val start = Button(this).apply { text = "Hangfigyelés indítása" }
        val stop = Button(this).apply { text = "Hangfigyelés leállítása" }

        start.setOnClickListener { requestAndStart() }
        stop.setOnClickListener {
            stopService(Intent(this, WakeWordService::class.java))
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    private fun requestAndStart() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), requestCode)
        } else {
            ContextCompat.startForegroundService(this, Intent(this, WakeWordService::class.java))
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            ContextCompat.startForegroundService(this, Intent(this, WakeWordService::class.java))
        }
    }
}
