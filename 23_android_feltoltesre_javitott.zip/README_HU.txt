23 – NATÍV ANDROID PROJEKT (ELŐKÉSZÍTŐ VERZIÓ)

Ez Android Studio-ban megnyitható Kotlin projektforrás, nem telepíthető APK.

Mit tartalmaz:
- fekete-arany 23 indítóképernyő
- mikrofonengedély kérése
- Android foreground microphone service indítása/leállítása
- magyar szövegfelolvasás motor előkészítése
- tartós értesítés a mikrofonfigyelésről

FONTOS KORLÁT:
A „Szia, 23!” felismerés még NINCS bekötve. A projektben szándékosan TODO jelölés van:
ehhez valódi, helyben futó wake-word motor és a „Szia 23” egyedi modellfájlja szükséges.
Nem lenne korrekt azt állítani, hogy a puszta szolgáltatás már felismeri a megszólítást.

Mi kell a teljes működéshez:
1. Android Studio és Android SDK.
2. Wake-word motor (például Picovoice Porcupine vagy sherpa-onnx).
3. A „Szia 23” magyar ébresztőszóhoz készített modellfájl és a motor beállítása.
4. A mikrofonfigyelés indítása a felhasználó által az alkalmazás megnyitásakor.
5. Androidon állandó értesítés és mikrofonengedély. A rendszer/gyártó akkumulátorkorlátozása leállíthatja a szolgáltatást.
6. APK összeállítása és aláírása Android Studio-ból.

Adatvédelem:
A háttérben történő ébresztőszó-felismerésnél a hangfeldolgozást célszerű teljesen a telefonon tartani.
A mikrofon aktív állapotát az Android értesítésben jelzi. A felhasználó bármikor leállíthatja.

A korábbi PWA prototípus:
23_sajat_ai_elso_verzio.zip
